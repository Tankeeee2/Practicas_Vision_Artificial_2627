Sample images
